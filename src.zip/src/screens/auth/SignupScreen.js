import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  StatusBar, ScrollView, KeyboardAvoidingView,
  Platform, Dimensions, Alert,
} from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../../theme';
import { registerUser } from '../../services/firebase/auth';

const { height } = Dimensions.get('window');

/**
 * SignupScreen — Teacher / Student Registration ONLY
 *
 * ✅ Role is limited to 'teacher' or 'student' — no admin option here.
 * ✅ Admin registration is a separate screen (AdminSignupScreen).
 * ✅ Calls registerUser() which sets role in Firestore.
 */
const SignupScreen = ({ navigation, route }) => {
  const initialRole = route?.params?.role === 'student' ? 'student' : 'teacher';
  const [role, setRole] = useState(initialRole);

  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    username: '',
    password: '',
    confirmPassword: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  const update = (key, val) => setForm((prev) => ({ ...prev, [key]: val }));

  const isFormValid =
    form.name.trim() &&
    form.email.trim() &&
    form.phone.trim() &&
    form.username.trim() &&
    form.password.trim().length >= 6 &&
    form.confirmPassword.trim() &&
    form.password === form.confirmPassword;

  const handleSignup = async () => {
    if (!isFormValid) return;
    setLoading(true);
    try {
      await registerUser({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        username: form.username.trim(),
        password: form.password,
        role, // 'teacher' or 'student' — set by the toggle above
      });
      Alert.alert(
        'Account Created ✅',
        `Your ${role} account has been created. Please log in.`,
        [{ text: 'Go to Login', onPress: () => navigation.navigate('Login') }]
      );
    } catch (error) {
      Alert.alert('Signup Failed', error.message || 'Could not create account.');
    } finally {
      setLoading(false);
    }
  };

  const fields = [
    { key: 'name',     label: 'Full Name',     placeholder: 'Enter your full name',    icon: '👤', keyboardType: 'default',       autoCapitalize: 'words' },
    { key: 'email',    label: 'Email Address', placeholder: 'Enter your email',         icon: '✉️', keyboardType: 'email-address', autoCapitalize: 'none' },
    { key: 'phone',    label: 'Phone Number',  placeholder: 'Enter your phone number',  icon: '📱', keyboardType: 'phone-pad',     autoCapitalize: 'none' },
    { key: 'username', label: 'Username',      placeholder: 'Choose a username',        icon: '🆔', keyboardType: 'default',       autoCapitalize: 'none' },
  ];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.primary} />

      <View style={styles.header}>
        <View style={styles.circle1} />
        <View style={styles.circle2} />
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backTxt}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.appName}>SAAPT</Text>
        <Text style={styles.appSubtitle}>Create Account</Text>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.card}>

            {/* Role Switcher — Teacher or Student ONLY */}
            <View style={styles.switcher}>
              <TouchableOpacity
                style={[styles.roleBtn, role === 'teacher' && styles.roleBtnActive]}
                onPress={() => setRole('teacher')}
                activeOpacity={0.8}
              >
                <Text style={[styles.roleTxt, role === 'teacher' && styles.roleTxtActive]}>
                  👩‍🏫  Teacher
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.roleBtn, role === 'student' && styles.roleBtnActive]}
                onPress={() => setRole('student')}
                activeOpacity={0.8}
              >
                <Text style={[styles.roleTxt, role === 'student' && styles.roleTxtActive]}>
                  🎓  Student
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.cardTitle}>
              {role === 'teacher' ? 'Teacher' : 'Student'} Registration
            </Text>
            <Text style={styles.cardSub}>Fill in your details to create your account.</Text>

            {fields.map((field) => (
              <View key={field.key} style={styles.inputWrap}>
                <Text style={styles.label}>{field.label}</Text>
                <View style={[styles.inputBox, form[field.key].length > 0 && styles.inputBoxActive]}>
                  <Text style={styles.icon}>{field.icon}</Text>
                  <TextInput
                    style={styles.input}
                    placeholder={field.placeholder}
                    placeholderTextColor={Colors.inputPlaceholder}
                    value={form[field.key]}
                    onChangeText={(val) => update(field.key, val)}
                    keyboardType={field.keyboardType}
                    autoCapitalize={field.autoCapitalize}
                    autoCorrect={false}
                  />
                </View>
              </View>
            ))}

            <View style={styles.inputWrap}>
              <Text style={styles.label}>Password</Text>
              <View style={[styles.inputBox, form.password.length > 0 && styles.inputBoxActive]}>
                <Text style={styles.icon}>🔒</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Min 6 characters"
                  placeholderTextColor={Colors.inputPlaceholder}
                  value={form.password}
                  onChangeText={(val) => update('password', val)}
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                  <Text style={styles.icon}>{showPassword ? '🙈' : '👁️'}</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.inputWrap}>
              <Text style={styles.label}>Confirm Password</Text>
              <View style={[
                styles.inputBox,
                form.confirmPassword.length > 0 && styles.inputBoxActive,
                form.confirmPassword.length > 0 && form.password !== form.confirmPassword && styles.inputBoxError,
              ]}>
                <Text style={styles.icon}>🔐</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Re-enter password"
                  placeholderTextColor={Colors.inputPlaceholder}
                  value={form.confirmPassword}
                  onChangeText={(val) => update('confirmPassword', val)}
                  secureTextEntry={!showConfirm}
                  autoCapitalize="none"
                />
                <TouchableOpacity onPress={() => setShowConfirm(!showConfirm)}>
                  <Text style={styles.icon}>{showConfirm ? '🙈' : '👁️'}</Text>
                </TouchableOpacity>
              </View>
              {form.confirmPassword.length > 0 && form.password !== form.confirmPassword && (
                <Text style={styles.errorTxt}>Passwords do not match</Text>
              )}
            </View>

            <TouchableOpacity
              style={[styles.btn, !isFormValid && styles.btnDisabled]}
              onPress={handleSignup}
              disabled={!isFormValid || loading}
              activeOpacity={0.85}
            >
              <Text style={[styles.btnTxt, !isFormValid && styles.btnTxtDisabled]}>
                {loading ? 'Creating Account...' : `Create ${role === 'teacher' ? 'Teacher' : 'Student'} Account`}
              </Text>
            </TouchableOpacity>

            <View style={styles.row}>
              <Text style={styles.rowTxt}>Already have an account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                <Text style={styles.rowLink}>Sign In</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default SignupScreen;

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F4F7F5' },
  header: {
    backgroundColor: Colors.primary,
    height: height * 0.22,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  circle1: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(255,255,255,0.05)', top: -60, right: -40 },
  circle2: { position: 'absolute', width: 140, height: 140, borderRadius: 70, backgroundColor: 'rgba(255,255,255,0.06)', bottom: -30, left: -20 },
  backBtn: { position: 'absolute', top: 16, left: 16 },
  backTxt: { color: 'rgba(255,255,255,0.85)', fontSize: 15, fontWeight: '600' },
  appName: { fontSize: 30, fontWeight: '800', color: '#fff', letterSpacing: 6 },
  appSubtitle: { fontSize: 14, color: 'rgba(255,255,255,0.82)', marginTop: 4, letterSpacing: 1 },
  scroll: { paddingHorizontal: 16, paddingBottom: 32, marginTop: -24 },
  card: {
    backgroundColor: '#fff', borderRadius: 20, padding: 24,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08, shadowRadius: 20, elevation: 6,
  },
  switcher: {
    flexDirection: 'row', backgroundColor: '#E6F0EA', borderRadius: 50,
    padding: 3, marginBottom: 20, height: 46, gap: 3,
  },
  roleBtn: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 50 },
  roleBtnActive: { backgroundColor: Colors.primary },
  roleTxt: { fontSize: 14, fontWeight: '500', color: Colors.primary },
  roleTxtActive: { color: '#fff', fontWeight: '700' },
  cardTitle: { fontSize: 22, fontWeight: '700', color: '#1C1C1C', marginBottom: 6 },
  cardSub: { fontSize: 13, color: '#6B6B6B', lineHeight: 20, marginBottom: 20 },
  inputWrap: { marginBottom: 14 },
  label: { fontSize: 13, fontWeight: '600', color: '#1C1C1C', marginBottom: 6 },
  inputBox: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1.5, borderColor: '#E0E0E0', borderRadius: 13,
    backgroundColor: '#fff', paddingHorizontal: 14, height: 52,
  },
  inputBoxActive: { borderColor: Colors.primary },
  inputBoxError: { borderColor: '#EF4444' },
  icon: { fontSize: 16, marginRight: 8 },
  input: { flex: 1, fontSize: 15, color: '#1C1C1C' },
  errorTxt: { fontSize: 12, color: '#EF4444', marginTop: 4, marginLeft: 4 },
  btn: {
    backgroundColor: Colors.primary, borderRadius: 50, height: 52,
    alignItems: 'center', justifyContent: 'center', marginTop: 10,
    shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, elevation: 4,
  },
  btnDisabled: { backgroundColor: '#D6D6D6', elevation: 0 },
  btnTxt: { color: '#fff', fontSize: 16, fontWeight: '700', letterSpacing: 0.5 },
  btnTxtDisabled: { color: '#8A8A8A' },
  row: { flexDirection: 'row', justifyContent: 'center', marginTop: 16 },
  rowTxt: { fontSize: 14, color: '#6B6B6B' },
  rowLink: { fontSize: 14, fontWeight: '700', color: Colors.primary },
});
